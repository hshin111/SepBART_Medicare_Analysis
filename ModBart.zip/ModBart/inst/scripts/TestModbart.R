## Load ---------------------------------------------------------------------

library(ModBart)
library(zeallot)
library(glmnet)

## Simulate functions -------------------------------------------------------

simulate_dunson <- function(N, P) {
  X <- matrix(runif(N * P), nrow = N)
  p <- exp(-2 * X[,1])
  mu_1 <- X[,1]
  mu_2 <- X[,1]^4
  sigma_1 <- sqrt(0.01)
  sigma_2 <- sqrt(0.04)
  
  Y <- ifelse(runif(N) < p, rnorm(N, mu_1, sigma_1), rnorm(N, mu_2, sigma_2))
  
  return(list(X = X, Y = Y))
}

density_dunson <- function(x,y) {
  if(is.matrix(x)) x <- x[1]
  out <- exp(-2 * x) * dnorm(y, x, sqrt(0.01)) + 
    (1 - exp(-2 * x)) * dnorm(y, x^4, sqrt(0.04))
}

mean_dunson <- function(x) {
  x * exp(-2 * x) + (1 - exp(-2 * x)) * x^4
}


## Function for simulating data ---------------------------------------------

set.seed(782078971)

N            <- 500
P            <- 5
c(X, Y)     %<-% simulate_dunson(N, 5)


x_pred <- matrix(seq(from = 0, to = 1, by = 0.02))
x_pred <- cbind(x_pred, matrix(0.5, nrow = length(x_pred), ncol = P - 1))
y_pred <- seq(from = -1, to = 2, length = 300)

## Fit ----------------------------------------------------------------------

hypers              <- Hypers(X = X, Y = Y, num_tree = 50, k = 1)
hypers$sigma_hat    <- 1
hypers$length_scale <- 2 * sd(Y) / pi
hypers$shape_length_scale <- 1
hypers$rate_length_scale <- 1 / hypers$length_scale^2
opts                <- Opts(update_sigma = FALSE, 
                            update_s = TRUE, 
                            update_alpha = TRUE)

fitted_modbart <- fit_modbart(X, X, Y, 
                              x_pred = x_pred, 
                              x_pred_bart = x_pred, 
                              y_pred = y_pred, 
                              hypers = hypers, opts = opts,
                              num_burn = 1000, num_thin = 4, num_save = floor(1000/4))


# Get Mean ----------------------------------------------------------------

dens_array <- fitted_modbart$f_pred

f <- function(xidx,iter) {
  vals <- dens_array[xidx,,iter]
  sum(y_pred * vals * (y_pred[2] - y_pred[1]))
}

mean_est <- outer(X = 1:nrow(x_pred), 
                  Y = 1:length(fitted_modbart$reject_size), 
                  FUN = Vectorize(f))

## Plots --------------------------------------------------------------------


par(mfrow = c(2,3))



f <- function(idx_x) {
  true_dens <- density_dunson(x_pred[idx_x,1], y_pred)
  ylim <- c(0,4)
  xlim <- c(-0.5,1.5)
  
  plot(y_pred, rowMeans(dens_array[idx_x,,]), ylim = ylim,
       xlim = xlim, type = 'l')
  lines(y_pred, density_dunson(x_pred[idx_x,1], y_pred), col= 'blue')
  
  quants <- apply(dens_array[idx_x,,], 1, function(x) quantile(x,c(.025,.975)))
  
  lines(y_pred, rowMeans(dens_array[idx_x,,]), ylim = ylim)
  lines(y_pred, density_dunson(x_pred[idx_x,1], y_pred), col= 'blue')
  lines(y_pred, quants[1,], lty = 3, lwd = 2)
  lines(y_pred, quants[2,], lty = 3, lwd=  2)
  
  sum(true_dens * log(rowMeans(dens_array[idx_x,,])))
}

idx_pred <-c(6,13,26,38,45)

par(mfrow = c(2,3))
tmp <- sapply(idx_pred, f)
mean(tmp)


plot(X[,1],Y, cex = .2)
library(RColorBrewer)
pal <- brewer.pal(8,"Paired")
lines(x_pred[,1], rowMeans(mean_est), col = pal[1], lwd = 3)
lines(x_pred[,1], apply(mean_est, 1, function(x) quantile(x, .025)), col = pal[4], lty = 2, lwd = 3)
lines(x_pred[,1], apply(mean_est, 1, function(x) quantile(x, .975)), col = pal[4], lty = 2, lwd = 3)
plot(mean_dunson, add = TRUE)

