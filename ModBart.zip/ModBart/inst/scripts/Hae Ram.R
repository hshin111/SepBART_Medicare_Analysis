

library(devtools)
install_local("~/Library/Mobile Documents/com~apple~CloudDocs/Research/2021_Environmental/CODE/ModBart.zip")

library(ModBart)
library(glmnet)

num_obs <- 200
set.seed(79927753+2)

t <- seq(from = 0, to = 1, length = num_obs)
X <- matrix(runif(num_obs * 2), nrow = num_obs, ncol = 2)
f1 <- function(t) t^2
f2 <- function(t) 1 - t^2
# f1 <- function(t) cos(6 * pi * t)
# f2 <- function(t) sin(6 * pi * t)
f <- function(x,t) ifelse(x < 0.5, 5 * cos(6 * pi * t), 5 * sin(6 * pi * t))
f <- function(x,t) ifelse(x < 0.5, f1(t), f2(t))
# f <- function(t) t^2
mu <- f(X[,1], t)
Y <- mu + 2^(-3) * rnorm(num_obs)

plot(t,Y)


# Make Object -------------------------------------------------------------

hypers <- Hypers(X = X, Y = Y, num_tree = 20)
hypers$length_scale <- 4 / pi
mean_ell_sq <- hypers$length_scale^2
hypers$shape_length_scale <- 1
hypers$rate_length_scale <- 1 / (mean_ell_sq)

t_test <- seq(from = 0.0073, to = .9976, length = num_obs)
X_test <- X; X_test[,1] <- 0.25; X_test[,2] <- 0.25
X_test_2 <- X_test; X_test_2[,1] <- 0.75

scaled_t <- (t - mean(t)) / sd(t)
scaled_t_test <- (t_test - mean(t)) / sd(t)

opts_1 <- Opts()
opts_2 <- Opts(update_sigma = FALSE)

forest_1 <- MakeForest(hypers = hypers, opts = opts_1)
forest_2 <- MakeForest(hypers = hypers, opts = opts_2)

mu_hat_2 <- numeric(length(Y))

#' Model: Y = forest_1(t,X) + forest_2(t,X) + sigma * error
#' First, update forest_1(t,X) using Y - forest_2(t,X)

R <- Y - mu_hat_2
mu_hat_1 <- as.numeric(forest_1$do_gibbs(X, R, scaled_t, X, scaled_t, 1))

#' Now, update forest_2(t,X) using Y - forest_1(t,X)

forest_2$set_sigma(forest_1$get_sigma())
R <- Y - mu_hat_1
mu_hat_2 <- as.numeric(forest_2$do_gibbs(X, R, scaled_t, X, scaled_t, 1))
forest_2$get_sigma()

#' forest(t,X) = sum_m cos(theta_m * t_m + omega_m) * tree_m(X)