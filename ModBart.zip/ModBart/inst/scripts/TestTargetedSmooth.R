## Load ----

library(ModBart)
library(glmnet)
library(viridis)
pal <- viridis(10)

## Generate Data ------------------------------------------------------------

num_obs <- 200
set.seed(79927753+2)

t <- seq(from = 0, to = 1, length = num_obs)
X <- matrix(runif(num_obs * 2), nrow = num_obs, ncol = 2)
f1 <- function(t) t^2
f2 <- function(t) 1 - t^2
# f1 <- function(t) cos(6 * pi * t)
# f2 <- function(t) sin(6 * pi * t)
f <- function(x,t) ifelse(x < 0.5, 5 * cos(6 * pi * t), 5 * sin(6 * pi * t))
f <- function(x,t) ifelse(x < 0.5, f1(t), f2(t))
# f <- function(t) t^2
mu <- f(X[,1], t)
Y <- mu + 2^(-3) * rnorm(num_obs)

plot(t,Y)


# Make Object -------------------------------------------------------------

hypers <- Hypers(X = X, Y = Y, num_tree = 20)
hypers$length_scale <- 4 / pi
mean_ell_sq <- hypers$length_scale^2
hypers$shape_length_scale <- 1
hypers$rate_length_scale <- 1 / (mean_ell_sq)
opts   <- Opts()

forest <- MakeForest(hypers = hypers, opts = opts)

t_test <- seq(from = 0.0073, to = .9976, length = num_obs)
X_test <- X; X_test[,1] <- 0.25; X_test[,2] <- 0.25
X_test_2 <- X_test; X_test_2[,1] <- 0.75

scaled_t <- (t - mean(t)) / sd(t)
scaled_t_test <- (t_test - mean(t)) / sd(t)

out <- forest$do_gibbs(X, Y, scaled_t, X_test, scaled_t_test, 3000)
out1 <- forest$do_gibbs(X, Y, scaled_t, X_test, scaled_t_test, 3000)
out2 <- forest$do_gibbs(X, Y, scaled_t, X_test_2, scaled_t_test, 3000)
plot(t,Y)
plot(f1, add = TRUE, col = pal[7], lwd = 3)
plot(f2, add = TRUE, col = pal[7], lwd = 3)
# lines(t,mu, type = 'l', col = pal[7], lwd = 3)
lines(t_test,colMeans(out1), pch = .5, col = pal[3], lwd = 3, lty = 3)
lines(t_test,colMeans(out2), pch = .5, col = pal[3], lwd = 3, lty = 3)


# Fourier decomp ----------------------------------------------------------

# f1 <- sin(t)
# f2 <- cos(t)
# f3 <- sin(2 * t)
# f4 <- cos(2 * t)
# f5 <- sin(3 * t)
# f6 <- cos(3 * t)
# 
# (lm(Y ~ f1 + f2 + f3 + f4 + f5 + f6))
# lines(t, predict(lm(Y ~ f1 + f2 + f3 + f4 + f5 + f6)))
