predict.Rcpp_Forest <- function(forest, X, include_burnin = FALSE) {
  
}